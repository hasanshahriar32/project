import React from 'react';

const Clock = () => {
    return (
        <div>
            
        </div>
    );
};

export default Clock;