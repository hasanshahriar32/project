import React from 'react';

const Calculate = () => {
    return (
        <div>
            
        </div>
    );
};

export default Calculate;